/**
 * Created by icastilho on 22/05/17.
 */
//# sourceMappingURL=loop.service.js.map