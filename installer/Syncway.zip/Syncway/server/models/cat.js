// import * as mongoose from "mongoose";
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/*
const catSchema = new mongoose.Schema({
  name: String,
  weight: Number,
  age: Number
});
*/
// const Cat = mongoose.model('Cat', catSchema);
var Cat = (function () {
    function Cat() {
    }
    return Cat;
}());
exports.default = Cat;
//# sourceMappingURL=cat.js.map