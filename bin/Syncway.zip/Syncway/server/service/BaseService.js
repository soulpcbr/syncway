/**
 * Created by icastilho on 22/05/17.
 */
//# sourceMappingURL=BaseService.js.map