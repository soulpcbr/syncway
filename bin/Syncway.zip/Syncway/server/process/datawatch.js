"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DataWatch = (function () {
    function DataWatch() {
    }
    DataWatch.prototype.addFile = function (filePath) {
    };
    return DataWatch;
}());
exports.DataWatch = DataWatch;
//# sourceMappingURL=datawatch.js.map