/**
 * Created by icastilho on 22/05/17.
 */
var Model = (function () {
    function Model() {
    }
    return Model;
}());
//# sourceMappingURL=base.model.js.map