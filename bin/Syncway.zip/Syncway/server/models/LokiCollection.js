/**
 * Created by icastilho on 20/05/17.
 */
var LokiCollection = (function () {
    function LokiCollection() {
    }
    return LokiCollection;
}());
;
//# sourceMappingURL=LokiCollection.js.map