/**
 * Created by icastilho on 19/05/17.
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/*const loopSchema = new mongoose.Schema({
});

const Loop = mongoose.model('Cat', loopSchema);*/
var Loop = (function () {
    function Loop() {
    }
    return Loop;
}());
exports.default = Loop;
//# sourceMappingURL=Loop.js.map