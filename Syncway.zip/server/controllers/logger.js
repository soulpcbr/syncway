"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var logger_1 = require("../logger");
var LoggerCtrl = (function () {
    function LoggerCtrl() {
        var _this = this;
        this.logs = function (req, res) {
            var from = req.param('from'), until = req.param('until'), limit = req.param('limit');
            _this.list({
                limit: limit,
                from: from,
                until: until,
            }).then(function (logs) {
                res.status(200).json({
                    logs: logs,
                });
            });
        };
        this.list = function (options) {
            options.limit = options.limit || 50;
            return new Promise(function (resolve, reject) {
                logger_1.default.query(options, function (error, logs) {
                    if (error) {
                        return reject(error);
                    }
                    resolve(logs);
                });
            });
        };
    }
    return LoggerCtrl;
}());
exports.LoggerCtrl = LoggerCtrl;
//# sourceMappingURL=logger.js.map