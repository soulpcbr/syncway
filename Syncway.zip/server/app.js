"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var bodyParser = require("body-parser");
var dotenv = require("dotenv");
var express = require("express");
var cors = require("cors");
var path = require("path");
var socketIo = require("socket.io");
dotenv.config();
var routes_1 = require("./routes");
var tasks_1 = require("./tasks");
var logger_1 = require("./logger");
var app = express();
exports.app = app;
app.use(cors());
app.set('port', (process.env.PORT || 3000));
app.use('/', express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
routes_1.default(app);
app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, 'public/index.html'));
});
var server = app.listen(app.get('port'), function () {
    logger_1.default.log('info', 'Angular Full Stack listening on port ' + app.get('port'));
});
/**
 * Socket events
 */
var io = socketIo(server, { transports: ['websocket'] });
tasks_1.default(io);
//# sourceMappingURL=app.js.map