"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var loop_task_1 = require("./task/loop.task");
/**
 * Created by icastilho on 22/05/17.
 */
function setTasks(io) {
    // const nsp = io.of('/status');
    var task = new loop_task_1.TaskLoop(io);
    io.on('connect', function (socket) {
        console.log('Connected client on port ');
        task.getTasks().forEach(function (t) {
            io.emit('status', { id: t.loop.$loki, status: 'CONNECTING', nextExecution: t.getDelay() + new Date().getTime() });
        });
        socket.on('disconnect', function () {
            console.log('Client disconnected');
        });
    });
    setTimeout(function () {
        task.start();
    }, 3000);
}
exports.default = setTasks;
//# sourceMappingURL=tasks.js.map